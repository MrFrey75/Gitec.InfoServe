﻿namespace Gitec.InfoServe.CommonLib;

public class Class1
{

}