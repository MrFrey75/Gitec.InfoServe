﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gitec.InfoServe.CommonLib.Enumerations;

public enum ServiceType
{
    UnknownService = 0,
    Database = 1,
    Network = 2,
    Authentication = 3,
    Storage = 4,
    Processing = 5
}