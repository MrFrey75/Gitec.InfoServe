﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gitec.InfoServe.CommonLib.Enumerations;

public enum StatusType
{
    UnknownStatus = 0,
    Success = 1,
    Failure = 2,
    Warning = 3,
    Pending = 4
}