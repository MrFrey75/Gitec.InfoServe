﻿using Gitec.InfoServe.CommonLib.Enumerations;
using Grpc.Core;

namespace Gitec.InfoServe.Api.Services;

public class SysHealthService : SysHealth.SysHealthBase
{
    public override Task<ServiceReply> SaveHealth(ClientRequest request, ServerCallContext context)
    {
        Console.WriteLine($"Received Health Check from {request.Client}");
        Console.WriteLine($"Service: {request.Service} | Details: {request.Details}");

        return Task.FromResult(new ServiceReply
        {
            Timestamp = Google.Protobuf.WellKnownTypes.Timestamp.FromDateTime(DateTime.UtcNow),
            Message = "Health check received.",
            Status = StatusType.Success // Use the generated StatusType enum
        });
    }
}